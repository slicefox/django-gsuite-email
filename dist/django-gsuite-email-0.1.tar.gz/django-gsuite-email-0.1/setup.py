from setuptools import setup

setup(install_requires=['google-api-python-client==1.8.0','google-auth==1.11.3'])