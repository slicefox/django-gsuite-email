=====
GSuite Email Backend
=====

This package helps send emails through google gsuite serviceaccount credentials

Quick start
-----------

1. Add this to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'django-gsuite-serviceaccount-emailbackend',
        ...
    ]

2. Set the Email EMAIL_BACKEND setting in settings like this::

    EMAIL_BACKEND = 'gsuite_emails.backends.GSuiteEmailBackend'