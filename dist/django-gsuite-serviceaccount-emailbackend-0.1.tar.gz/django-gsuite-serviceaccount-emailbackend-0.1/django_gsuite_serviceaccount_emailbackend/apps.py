from django.apps import AppConfig


class GsuiteEmailsConfig(AppConfig):
    name = 'gsuite_emails'
