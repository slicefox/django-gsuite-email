from django.apps import AppConfig

class DjangoGSuiteEmailConfig(AppConfig):
    name = 'django_gsuite_email'
    verbose_name = "Django GSuite Email"